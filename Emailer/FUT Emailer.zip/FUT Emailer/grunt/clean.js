// Clean your /dist folder
module.exports = {
  clean: ["dist"]
};
