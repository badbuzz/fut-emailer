// Browser-based preview task
module.exports = {
  preview: {
    path: 'http://localhost:4000'
  }
}